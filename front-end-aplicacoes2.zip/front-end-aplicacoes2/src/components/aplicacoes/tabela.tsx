import Aplicacao from "@/core/Aplicacao"
import { IconeEdicao, IconeLixo } from "../icones/tabela"

interface TabelaProps {
    aplicacoes: Aplicacao[]
    aplicacaoSelecionada?: (aplicacao: Aplicacao) => void
    aplicacaoExcluida?: (aplicacao: Aplicacao) => void
}

export default function Tabela(props: TabelaProps) {

    const exibirAcoes = props.aplicacaoSelecionada || props.aplicacaoExcluida

    function renderHeader() {
        return (
            <tr>
                <th className="text-left p-3">ID</th>
                <th className="text-left p-3">NOME</th>
                <th className="text-left p-3">DESCRIÇÃO</th>
                <th className="text-left p-3">STATUS</th>
                {exibirAcoes ? <th className="p-3">AÇÕES</th> : false}
            </tr>
        )
    }
    function renderDados() {
        return props.aplicacoes?.map((aplicacao, i) => {
            return (
                <tr key={aplicacao.id}
                    className={`${i % 2 === 0 ? 'bg-blue-200' : 'bg-cyan-200'} `}>
                    <td className="text-left p-3">{aplicacao.id}</td>
                    <td className="text-left p-3">{aplicacao.nome}</td>
                   
                    <td className="text-left p-3">{aplicacao.descricao}</td>
                    <td className="text-left p-3">{aplicacao.status}</td>
                    {exibirAcoes ? renderizarAcoes(aplicacao) : false}
                </tr>)
        })
    }
    return (
        <table className="w-full rounded-xl overflow-hidden">
            <thead className={`text-gray-900
        bg-gradient-to-r from-blue-800 via-purple-300 to-cyan-400`}>
                {renderHeader()}
            </thead>
            <tbody>
                {renderDados()}
            </tbody>
        </table>
    )

    function renderizarAcoes(aplicacao: Aplicacao) {
        return (
            <td className="flex justify-center">
                {props.aplicacaoSelecionada
                    ? (<button onClick={() => props.aplicacaoSelecionada?.(aplicacao)}
                        className={`flex justify-center items text-green-600 rounded-full p-2 m-1 hover:bg-gray-100`}>{IconeEdicao}</button>)
                    : false}
                {props.aplicacaoExcluida
                    ? (<button onClick={() => props.aplicacaoExcluida?.(aplicacao)}
                        className={`flex justify-center items text-red-600 rounded-full p-2 m-1 hover:bg-gray-100`}>{IconeLixo}</button>)
                    : false}
            </td>
        )
    }
}
