import React from "react";

export default function Navbar(props: any) {
    return (
        <>
            <nav className="font-serif flex flex-col text-center sm:flex-row sm:text-left sm:justify-between py-6 px-8 bg-gray-800 text-stone-100 shadow sm:items-baseline w-full">
                <div className="mb-2 sm:mb-0 text-3x1">
                    <strong>Sistema de aplicacoes</strong>
                </div>
                <div className="flex items-center"> 
                    <a href="/" className="text-lg no-underline hover:text-blue-400 ml-2 inline-block">
                    <strong> Home </strong></a>

                    <a href="/aplicacoes" className="text-lg no-underline hover:text-purple-300 ml-4">
                    <strong> Aplicações </strong></a>
                </div>
            </nav>
        </>
    );
}
