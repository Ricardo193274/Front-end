'use client';
import Botao from "@/components/aplicacoes/botao";
import Formulario from "@/components/aplicacoes/Formulario";
import Layout from "@/components/aplicacoes/Layout";
import Tabela from "@/components/aplicacoes/Tabela";
import Aplicacao from "@/core/Aplicacao";
import { atualizarAplicacao, cadastrarAplicacao, excluirAplicacao, fetchAplicacoes } from "@/service/aplicacaoService";
import { useEffect, useState } from "react";

export default function Aplicacoes() {

  const [aplicacao, setAplicacao] = useState<Aplicacao>(Aplicacao.vazio())
  const [visivel, setVisivel] = useState<'tabela' | 'form'>('tabela')

  const [aplicacoes, setAplicacoes] = useState<Aplicacao[]>([]);

  useEffect(() => {
    if (visivel === 'tabela') {
      const loadAplicacoes = async () => {
        try {
          const dados = await fetchAplicacoes();
          setAplicacoes(dados);
        } catch (error) {
          console.error("Erro ao buscar aplicações:", error);
        }
      }

      loadAplicacoes();
    }
  }, [visivel]);

  function aplicacaoSelecionada(aplicacao: Aplicacao) {
    setAplicacao(aplicacao)
    setVisivel('form')
  }

  async function aplicacaoExcluida(aplicacao: Aplicacao) {
    const confirmacao = window.confirm("Tem certeza de que deseja excluir esta aplicação?");
    if (confirmacao) {
      try {
        if (aplicacao.id !== null) {
          await excluirAplicacao(aplicacao.id);
        } else {
          console.error("aplicacaoId é null!");
        }
        setAplicacoes(prevAplicacoes => prevAplicacoes.filter(ev => ev.id !== aplicacao.id));
      } catch (error) {
        console.error("Erro ao excluir aplicação:", error);
      }
    }
  }

  function salvarOuAlterarAplicacao(aplicacao: Aplicacao) {
    if (aplicacao.id) {
      alterarAplicacao(aplicacao)
    } else {
      salvarAplicacao(aplicacao)
    }
  }

  async function alterarAplicacao(aplicacao: Aplicacao) {
    try {
      const aplicacaoAtualizada = await atualizarAplicacao(aplicacao);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao atualizar aplicação:", error);
    }
  }

  async function salvarAplicacao(aplicacao: Aplicacao) {
    try {
      const novaAplicacao = await cadastrarAplicacao(aplicacao);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao salvar aplicação:", error);
    }
  }

  function novaAplicacao() {
    setAplicacao(Aplicacao.vazio())
    setVisivel("form")
  }

  return (
    <div className={`
     flex justify-center items-center h-screen
     bg-gradient-to-bl from-indigo-900 via-indigo-400 to-indigo-900
     text-white`}
     style={{
      backgroundImage: 'url(\'\')',
      backgroundSize: 'cover',
     }}>
      <Layout titulo="Cadastro de aplicações">
        {visivel === 'tabela' ? (
          <>
            <div className="flex justify-end">
              <Botao className="mb-4" cor="text-gray-200
            bg-gradient-to-r from-blue-500 to-indigo-800"
                onClick={() => novaAplicacao()}>
                Nova aplicação
              </Botao>
            </div>
            <Tabela aplicacoes={aplicacoes}
              aplicacaoSelecionada={aplicacaoSelecionada}
              aplicacaoExcluida={aplicacaoExcluida}></Tabela>
          </>
        ) : (
          <Formulario aplicacao={aplicacao}
            aplicacaoMudou={salvarOuAlterarAplicacao}
            cancelado={() => setVisivel('tabela')} />
        )}
      </Layout>
    </div>
  )
}
