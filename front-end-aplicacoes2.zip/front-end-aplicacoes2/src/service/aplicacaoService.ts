import Aplicacao from '../core/Aplicacao';

let aplicacoesList: Aplicacao[] = [
  new Aplicacao(1, "Instagram",
    "APP",
    "ABERTO",
  ),
  new Aplicacao(2, "Facebook",
    "APP",
    "ABERTO",
  )
]

let proximoId = aplicacoesList.length + 1;

export const fetchAplicacoes = async (): Promise<Aplicacao[]> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return aplicacoesList;
  } catch (error) {
    throw new Error('Erro ao buscar aplicações');
  }
};

export const cadastrarAplicacao = async (novaAplicacao: Aplicacao): Promise<Aplicacao> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    novaAplicacao.id = proximoId++;
    aplicacoesList.push(novaAplicacao);
    return novaAplicacao;
  } catch (error) {
    console.error("Erro ao cadastrar aplicação:", error);
    throw error;
  }
};

export const atualizarAplicacao = async (aplicacaoAtualizada: Aplicacao): Promise<Aplicacao> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const index = aplicacoesList.findIndex((aplicacao) => aplicacao.id === aplicacaoAtualizada.id);
    if (index !== -1) {
      aplicacoesList[index] = aplicacaoAtualizada;
      return aplicacaoAtualizada;
    } else {
      throw new Error('Aplicação não encontrada');
    }
  } catch (error) {
    console.error("Erro ao atualizar aplicação:", error);
    throw error;
  }
};

export const excluirAplicacao = async (id: number): Promise<void> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    aplicacoesList = aplicacoesList.filter((aplicacao) => aplicacao.id !== id);
  } catch (error) {
    console.error("Erro ao excluir aplicação:", error);
    throw error;
  }
};
