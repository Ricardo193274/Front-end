import { stringParaEntradaDeData } from "@/utils/converters";
import { ReactNode } from "react";

export default class Aplicacao {
  id: number | null;
  nome: string;
  descricao: string;
  status: string;

  constructor(id: number | null, nome: string, descricao: string, status: string) {
    this.id = id;
    this.nome = nome;
    this.descricao = descricao;
    this.status = status;
  }

  static geraAplicacoesMock() {
    return [
      new Aplicacao(1, "Instagram", "APP", "Aberto"),
      new Aplicacao(2, "Facebook", "APP", "Aberto"),
    ];
  }

  static vazio(): Aplicacao {
    return new Aplicacao(null, "", "", "");
  }


  aplicacao(): string {
    return `Modelo: ${this.nome}, Ano: ${this.descricao}, Status: ${this.status}`;
  }
}
